package com.example.note52;

public class Note52 {
    public static void main(String args[]) {

        System.out.println("coming soon on 17/04/2023");
        System.out.println("If there is a change in the date, I will inform you here");
        System.out.println("Hello World!");
    }



}
