package com.example.note52;

public class Degiskenler {

    public static void main(String args[]){

        String kisininAdi = "Buğra";
        int kisininYasi = 14;
        double kisininBoyu = 1.72;
        boolean turkMu = true ;
        int a = 10;
        int b = 50;

         System.out.println(a+b);

    }

}
